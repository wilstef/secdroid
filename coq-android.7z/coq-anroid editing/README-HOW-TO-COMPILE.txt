
 This code has been created and compiled with Coq 8.2pl2 (June 2010).
 NOTE: Coq 8.2p12 for Windows some time can not be compiled (it can be installed
 successfully though). Coqc is working, but coqide and coqtop can not be run. In
 that case, try run coq.byte.exe, coqtop.byte.exe, so on)

 To complite the main library 'Language_Based_Security_Android.v', you must
 have 'make' program. It is not there, copy (from Software/Coq software folder) and
 past it in C:/Windows/Systme32.
 Go to the folder having the above library on command prompt.

 >cd coq-android 

  Then create Makefile
 > coq_makefile -o Makefile -no-install *.v  
  (or specify list of libraries separated with space such as abc.v cba.v ...)

  Then compile/create exe (.vo) file. The make command will execute the library and
  all the required libraries.
 > make Language_Based_Security_Android.vo

OR

 To compile the programe X.v, the libraries included (like Metatheory.vo) 
 must be stored in directory where x.v is stored, or anywhere in any of its
 parent directory. 

 To create executable Coq file (y.vo) of a file (y.v), use the command 
 coqc in command line. For this to use successfully, one way is: 

 1) go to the Coq folder in C:\, using command C:\cd coq. 
 2) Then copy the files Coq, Coqc, Coqide from 'bin' to folder Coq. 
 3) Create a folder say 'sf' in folder Coq. 
 4) Copy the file 'y.v' to 'sf' folder. 
 5) Enter to folder 'sf' using C:\ Coq\ cd sf
 6) Execute file y.v using coqc, using command C:\Coq\coqc sf.v
 7) It will create file 'y.vo' in 'sf'. Copy and past it where 'x.v' is 
    stored, as described above. 


 